let numbers = [2,1,4,5,6,3,7,8,1,4,6,8,1,5,7,8,3]

// Put your code here

let temporal;
let posicion;

for(let i = 0; i < numbers.length; i++){
    temporal = numbers[i];
    aux = numbers[i];
   
    for(let j = i;j < numbers.length;j++){
        if(temporal > numbers[j+1]){
            temporal = numbers[j+1];
            posicion = j+1;
            numbers[i] = temporal;
            
        }
       
    }
    
    numbers[posicion] = aux;

}
console.log(`Ordenando ${numbers}`);