# Oh, my f@k#ng sorting algorithm!
* Analiza el ejemplos en [example.js](example.js)
* Implementa en [index.js](index.js) el siguiente algoritmo para ordenar los números en un array.
    * Compara el primer elemento del array con cada uno de los siguientes. Si alguno de los elementos siguientes es más pequeño que el primero, intercambia la posición de ese elemento y el primero. Ya tenemos el elemento más pequeño en la primera posición.
    * Ahora toma el segundo elemento de la lista y compáralo con cada uno de los siguientes elementos. Si algún elemento es más pequeño que el segundo, intercambia su posición con el segundo.
    * Prodece de igual manera para el resto de elementos de la lista consecutivamente.

