const numbers = [10,11,12,13,14,15,16];
const minimun = 13;

for ( item of numbers ) {
    if ( item >= minimun ) {
        console.log(`${item} is greater or equal to ${minimun}`)
    }
}
