const numbers = ["Frodo","Gandalf","Turin","Sauron","Saruman","Bilbo"];

// Put your code here
let start = 3;
let end = 6;
let step = 1;
for (let idx = start; idx < end; idx+=step) {
    console.log(numbers[idx]);
}
