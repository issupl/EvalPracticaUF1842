for (let outer = 0; outer < 2 ; outer++) {
    for (let inner = 0; inner < 3; inner++ ){
        console.log(`Outer: ${outer}, Inner: ${inner}`);
    }
}
