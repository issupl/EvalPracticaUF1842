// Put your code here

for (let outer = 0; outer < 10 ; outer++) {
    console.log(`Tabla del: ${outer}: `);
    for (let inner = 0; inner < 11; inner++ ){
        let multiplicacionTabla = outer*inner;
        console.log(`Resultado ${outer}*${inner} ${multiplicacionTabla}`)
        
    }
    console.log('\n');
}