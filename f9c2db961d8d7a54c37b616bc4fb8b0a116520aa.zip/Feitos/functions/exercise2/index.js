number = 0;

function plusOne(number) {
    number = number + 1;
    console.log('number',number)
    return number;
}

number = plusOne(number);

console.log(number)